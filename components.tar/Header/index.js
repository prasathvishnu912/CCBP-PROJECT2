import Cookies from 'js-cookie'
import {Link, withRouter} from 'react-router-dom'

import './index.css'

const Header = props => {
  const logoutBtnClicked = () => {
    const {history} = props
    Cookies.remove('jwt_token')
    history.replace('/login')
  }

  return (
    <ul className="header-app-card">
      <li>
        <Link to="/">
          <img
            src="https://assets.ccbp.in/frontend/react-js/logo-img.png"
            alt="website logo"
            className="header-website-logo"
          />
        </Link>
      </li>
      <li>
        <div className="link-name-card">
          <Link to="/">
            <p className="link-name">Home</p>
          </Link>
          <Link to="/jobs">
            <p className="link-name">Jobs</p>
          </Link>
        </div>
      </li>
      <li>
        <button type="button" className="logout-btn" onClick={logoutBtnClicked}>
          Logout
        </button>
      </li>
    </ul>
  )
}

export default withRouter(Header)
