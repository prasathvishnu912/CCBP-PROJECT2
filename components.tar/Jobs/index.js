import {Component} from 'react'
import Cookies from 'js-cookie'
import Loader from 'react-loader-spinner'
import {BsSearch} from 'react-icons/bs'

import Header from '../Header'
import JobList from '../JobList'
import './index.css'

const employmentTypesList = [
  {
    label: 'Full Time',
    employmentTypeId: 'FULLTIME',
  },
  {
    label: 'Part Time',
    employmentTypeId: 'PARTTIME',
  },
  {
    label: 'Freelance',
    employmentTypeId: 'FREELANCE',
  },
  {
    label: 'Internship',
    employmentTypeId: 'INTERNSHIP',
  },
]

const salaryRangesList = [
  {
    salaryRangeId: '1000000',
    label: '10 LPA and above',
  },
  {
    salaryRangeId: '2000000',
    label: '20 LPA and above',
  },
  {
    salaryRangeId: '3000000',
    label: '30 LPA and above',
  },
  {
    salaryRangeId: '4000000',
    label: '40 LPA and above',
  },
]
const apiCallConstants = {
  initial: '',
  loading: 'LOADING',
  success: 'SUCCESS',
  failure: 'FAILURE',
}
class Jobs extends Component {
  state = {
    profileApiView: apiCallConstants.initial,
    profileDetails: [],
    employmentType: '',
    salaryRange: '',
    userSearch: '',
    jobsList: [],
    jobsListView: '',
  }

  componentDidMount() {
    this.getProfileDetails()
    this.getJobsList()
  }

  getProfileDetails = async () => {
    this.setState({profileApiView: apiCallConstants.loading})

    const jwtToken = Cookies.get('jwt_token')

    const url = 'https://apis.ccbp.in/profile'
    const options = {
      method: 'GET',
      headers: {Authorization: `Bearer ${jwtToken}`},
    }
    const response = await fetch(url, options)
    if (response.ok === true) {
      const data = await response.json()
      const profileDetails = {
        name: data.profile_details.name,
        imageUrl: data.profile_details.profile_image_url,
        shortBio: data.profile_details.short_bio,
      }
      this.setState({profileApiView: apiCallConstants.success, profileDetails})
    } else {
      this.setState({profileApiView: apiCallConstants.failure})
    }
  }

  getJobsList = async () => {
    this.setState({jobsListView: apiCallConstants.loading})
    const {employmentType, salaryRange, userSearch} = this.state

    const jwtToken = Cookies.get('jwt_token')
    const url = `https://apis.ccbp.in/jobs?employment_type=${employmentType}&minimum_package=${salaryRange}&search=${userSearch}`
    const options = {
      method: 'GET',
      headers: {Authorization: `Bearer ${jwtToken}`},
    }

    const response = await fetch(url, options)
    if (response.ok === true) {
      const data = await response.json()
      const jobsList = data.jobs.map(eachJob => ({
        companyLogoUrl: eachJob.company_logo_url,
        employmentType: eachJob.employment_type,
        id: eachJob.id,
        jobDesc: eachJob.job_description,
        location: eachJob.location,
        package: eachJob.package_per_annum,
        rating: eachJob.rating,
        title: eachJob.title,
      }))
      this.setState({jobsListView: apiCallConstants.success, jobsList})
    } else {
      this.setState({jobsListView: apiCallConstants.failure})
    }
  }

  renderLoadingView = () => (
    <div className="loader-container" data-testid="loader">
      <Loader type="ThreeDots" color="#4f46e5" height="50" width="50" />
    </div>
  )

  renderSuccessProfileView = () => {
    const {profileDetails} = this.state
    const {name, imageUrl, shortBio} = profileDetails

    return (
      <div className="profile-details-card">
        <img src={imageUrl} alt="profile" className="profile-image" />
        <h1 className="profile-name">{name}</h1>
        <p className="profile-short-bio">{shortBio}</p>
      </div>
    )
  }

  onClickProfileRetryBtn = () => {
    this.getProfileDetails()
  }

  renderFailureProfileView = () => (
    <div className="failure-view-profile-card">
      <button
        type="button"
        className="failure-view-retry-btn"
        onClick={this.onClickProfileRetryBtn}
      >
        Retry
      </button>
    </div>
  )

  renderProfileDetails = () => {
    const {profileApiView} = this.state

    switch (profileApiView) {
      case apiCallConstants.failure:
        return this.renderFailureProfileView()
      case apiCallConstants.success:
        return this.renderSuccessProfileView()
      case apiCallConstants.loading:
        return this.renderLoadingView()
      default:
        return ''
    }
  }

  onChangeEmploymentType = event => {
    this.setState({employmentType: event.target.value})
  }

  renderEmploymentFilters = () => (
    <div className="filter-card">
      <hr className="hr-line" />
      <h1 className="filter-heading">Type of Employment</h1>
      <ul className="filter-list">
        {employmentTypesList.map(eachFilter => (
          <li className="each-filter" key={eachFilter.employmentTypeId}>
            <label className="filter-label">
              <input
                type="checkbox"
                value={eachFilter.employmentTypeId}
                onChange={this.onChangeEmploymentType}
                className="check-box"
              />
              {eachFilter.label}
            </label>
          </li>
        ))}
      </ul>
    </div>
  )

  onChangeSalaryRange = event => {
    this.setState({salaryRange: event.target.value})
  }

  renderSalaryRangeFilters = () => (
    <div className="filter-card">
      <hr className="hr-line" />
      <h1 className="filter-heading">Salary Range</h1>
      <ul className="filter-list">
        {salaryRangesList.map(eachFilter => (
          <li className="each-filter" key={eachFilter.salaryRangeId}>
            <label className="filter-label">
              <input
                type="radio"
                value={eachFilter.salaryRangeId}
                onChange={this.onChangeSalaryRange}
              />
              {eachFilter.label}
            </label>
          </li>
        ))}
      </ul>
    </div>
  )

  onClickJobsRetryBtn = () => {
    this.getJobsList()
  }

  renderJobsListFailureView = () => (
    <div className="jobs-list-failure-card">
      <img
        src="https://assets.ccbp.in/frontend/react-js/failure-img.png"
        alt="failure view"
        className="jobs-failure-view-image"
      />
      <h1 className="jobs-failure-view-heading">Oops! Something Went Wrong</h1>
      <p className="jobs-failure-view-description">
        We cannot seem to find the page you are looking for.
      </p>
      <button
        type="button"
        className="failure-view-retry-btn"
        onClick={this.onClickJobsRetryBtn}
      >
        Retry
      </button>
    </div>
  )

  renderJobsListSuccessView = () => {
    const {jobsList} = this.state

    return (
      <ul className="success-jobs-list-card">
        {jobsList.map(eachJob => (
          <JobList key={eachJob.id} jobDetails={eachJob} />
        ))}
      </ul>
    )
  }

  renderJobsList = () => {
    const {jobsListView} = this.state

    switch (jobsListView) {
      case apiCallConstants.loading:
        return this.renderLoadingView()
      case apiCallConstants.failure:
        return this.renderJobsListFailureView()
      case apiCallConstants.success:
        return this.renderJobsListSuccessView()
      default:
        return ''
    }
  }

  onClickSearchBtn = () => {
    this.getJobsList()
  }

  onChangeUserInput = event => {
    this.setState({userSearch: event.target.value})
  }

  render() {
    const {userSearch} = this.state
    return (
      <div className="jobs-app-container">
        <Header />
        <div className="jobs-card">
          <div className="jobs-filter-card">
            {this.renderProfileDetails()}
            {this.renderEmploymentFilters()}
            {this.renderSalaryRangeFilters()}
          </div>
          <div className="jobs-search-list-card">
            <div className="jobs-search-field">
              <input
                type="search"
                value={userSearch}
                onChange={this.onChangeUserInput}
                className="jobs-user-search"
                placeholder="Search"
              />
              <button
                type="button"
                data-testid="searchButton"
                className="search-icon-btn"
                onClick={this.onClickSearchBtn}
              >
                <BsSearch className="search-icon" />
              </button>
            </div>
            {this.renderJobsList()}
          </div>
        </div>
      </div>
    )
  }
}
export default Jobs
