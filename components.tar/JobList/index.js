import {Link} from 'react-router-dom'

import {AiFillStar} from 'react-icons/ai'
import {MdLocationOn} from 'react-icons/md'
import {FcBusiness} from 'react-icons/fc'

import './index.css'

const JobList = props => {
  const {jobDetails} = props
  const {
    id,
    companyLogoUrl,
    employmentType,
    jobDesc,
    location,
    rating,
    title,
  } = jobDetails

  return (
    <li>
      <Link to={`jobs/:${id}`}>
        <div className="job-list">
          <div className="logo-title-rating-card">
            <img
              src={companyLogoUrl}
              alt="job details company logo"
              className="job-details-company-logo"
            />
            <div className="rating-title-card">
              <h2 className="title">{title}</h2>
              <div className="rating-card">
                <AiFillStar className="rating-star" />
                <p className="rating-value">{rating}</p>
              </div>
            </div>
          </div>
          <div className="location-employment-card">
            <div className="logo-card">
              <MdLocationOn className="logo-image" />
              <p className="logo-name">{location}</p>
            </div>
            <div className="logo-card">
              <FcBusiness className="logo-image" />
              <p className="logo-name">{employmentType}</p>
            </div>
          </div>
          <hr className="hr-line" />
          <h2 className="description">Description</h2>
          <p className="job-description">{jobDesc}</p>
        </div>
      </Link>
    </li>
  )
}

export default JobList
